import {useEffect, useState} from 'react';
import {Bookmark, Check, Copy, Play, X} from 'lucide-react';
import {DocumentaryRelease} from '../data/historyData';
import {ArchivalImage} from './ArchivalImage';

interface EpisodeModalProps {
  release: DocumentaryRelease | null;
  isSaved: boolean;
  onToggleSave: (id: string) => void;
  onClose: () => void;
}

export function EpisodeModal({
  release,
  isSaved,
  onToggleSave,
  onClose,
}: EpisodeModalProps) {
  const [activeChapterIdx, setActiveChapterIdx] = useState(0);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setActiveChapterIdx(0);
    setCopied(false);
  }, [release?.id]);

  useEffect(() => {
    if (!release) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [release, onClose]);

  if (!release) return null;

  const formatLabel =
    release.format === 'youtube' ? 'مستند یوتیوب' : 'پرونده مصور اینستاگرام';

  const handleCopyShare = () => {
    const shareUrl = `${window.location.origin}/#release-${release.id}`;
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(shareUrl).catch(() => {});
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2200);
  };

  const activeChapter = release.chapters[activeChapterIdx] ?? release.chapters[0];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4 md:p-8 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="episode-modal-title"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-[#F9F8F6] border border-[#E2DDD3] rounded-xl overflow-hidden my-auto max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top bar */}
        <div className="flex items-center justify-between gap-4 px-6 py-4 border-b border-[#E2DDD3] bg-[#F4F1EA]">
          <div className="flex items-center gap-2 text-xs text-[#57534E] truncate">
            <span>{release.episodeNumber}</span>
            <span aria-hidden="true">·</span>
            <span>{formatLabel}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{release.durationOrSlides}</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => onToggleSave(release.id)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                isSaved
                  ? 'bg-[#1E3A8A] text-white border-[#1E3A8A]'
                  : 'bg-[#F9F8F6] text-[#181715] border-[#D6D0C4] hover:border-[#181715]'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" strokeWidth={1.75} />
              <span>{isSaved ? 'ذخیره شده' : 'ذخیره در فهرست'}</span>
            </button>
            <button
              type="button"
              onClick={handleCopyShare}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-[#D6D0C4] bg-[#F9F8F6] text-[#181715] hover:border-[#181715] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#14532D]" strokeWidth={2} />
                  <span>کپی شد</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" strokeWidth={1.75} />
                  <span>کپی لینک</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="بستن پنجره"
              className="p-2 rounded-lg text-[#57534E] hover:text-[#181715] hover:bg-[#E7E2D8] transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto p-6 md:p-8 space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-6 space-y-3">
              <div className="relative aspect-[4/3] rounded-lg overflow-hidden bg-[#EFECE6] border border-[#E2DDD3]">
                <ArchivalImage
                  src={release.image}
                  alt={release.imageAlt}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent flex items-end p-5">
                  <div className="text-white space-y-1">
                    <div className="flex items-center gap-2 text-xs text-stone-200">
                      <Play className="w-3.5 h-3.5" />
                      <span>{activeChapter?.time}</span>
                      <span aria-hidden="true">·</span>
                      <span>{activeChapter?.title}</span>
                    </div>
                  </div>
                </div>
              </div>
              <p className="text-xs text-[#57534E] leading-relaxed">
                {activeChapter?.summary}
              </p>
            </div>

            <div className="lg:col-span-6 space-y-5">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-xs text-[#57534E]">
                  <span>{release.era}</span>
                  <span aria-hidden="true">·</span>
                  <span>انتشار: {release.publishedDate}</span>
                </div>
                <h2
                  id="episode-modal-title"
                  className="font-serif text-2xl md:text-3xl font-bold text-[#181715] leading-snug"
                >
                  {release.title}
                </h2>
                <p className="text-sm text-[#44403C] leading-relaxed">
                  {release.subtitle}
                </p>
              </div>

              <p className="text-sm text-[#292524] leading-loose border-t border-[#E2DDD3] pt-4">
                {release.summary}
              </p>

              {/* Chapters Breakdown */}
              <div className="space-y-2 pt-2">
                <h3 className="text-xs font-semibold text-[#57534E]">
                  فهرست بخش‌های این روایت
                </h3>
                <div className="divide-y divide-[#E2DDD3] border border-[#E2DDD3] rounded-lg bg-[#F4F1EA]/50">
                  {release.chapters.map((chap, idx) => {
                    const isActive = idx === activeChapterIdx;
                    return (
                      <button
                        key={chap.title}
                        type="button"
                        onClick={() => setActiveChapterIdx(idx)}
                        className={`w-full text-right px-4 py-3 flex items-center justify-between gap-4 transition-colors cursor-pointer ${
                          isActive
                            ? 'bg-[#EFECE6] text-[#1E3A8A] font-semibold'
                            : 'hover:bg-[#EFECE6]/60 text-[#181715]'
                        }`}
                      >
                        <span className="text-sm truncate">{chap.title}</span>
                        <span className="text-xs text-[#57534E] tabular-nums shrink-0">
                          {chap.time}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Bibliography */}
          <div className="border-t border-[#E2DDD3] pt-6 space-y-3">
            <h3 className="text-sm font-semibold text-[#181715]">
              منابع و مآخذ پژوهشی این قسمت
            </h3>
            <ul className="space-y-2 text-sm text-[#44403C]">
              {release.sources.map((src, i) => (
                <li key={src} className="flex items-start gap-2.5 leading-relaxed">
                  <span className="text-xs text-[#78716C] tabular-nums mt-1 shrink-0">
                    {i + 1}.
                  </span>
                  <span>{src}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
