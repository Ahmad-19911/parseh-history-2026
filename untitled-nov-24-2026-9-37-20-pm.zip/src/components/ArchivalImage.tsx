import {useState} from 'react';
import {Landmark} from 'lucide-react';

interface ArchivalImageProps {
  src: string;
  alt: string;
  className?: string;
}

export function ArchivalImage({src, alt, className = ''}: ArchivalImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center bg-[#EFECE6] text-[#57534E] border border-[#E2DDD3] p-6 text-center ${className}`}
      >
        <Landmark className="w-8 h-8 mb-3 text-[#78716C]" strokeWidth={1.5} />
        <p className="text-xs leading-relaxed max-w-[22ch]">{alt}</p>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
}
