import {useEffect, useState} from 'react';
import {Bookmark, X, ZoomIn, ZoomOut} from 'lucide-react';
import {MuseumArtifact} from '../data/historyData';
import {ArchivalImage} from './ArchivalImage';

interface ArtifactModalProps {
  artifact: MuseumArtifact | null;
  isSaved: boolean;
  onToggleSave: (id: string) => void;
  onClose: () => void;
}

export function ArtifactModal({
  artifact,
  isSaved,
  onToggleSave,
  onClose,
}: ArtifactModalProps) {
  const [zoomed, setZoomed] = useState(false);

  useEffect(() => {
    setZoomed(false);
  }, [artifact?.id]);

  useEffect(() => {
    if (!artifact) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [artifact, onClose]);

  if (!artifact) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4 md:p-8 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="artifact-modal-title"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-5xl bg-[#F9F8F6] border border-[#E2DDD3] rounded-xl overflow-hidden my-auto max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-4 px-6 py-4 border-b border-[#E2DDD3] bg-[#F4F1EA]">
          <div className="flex items-center gap-2 text-xs text-[#57534E] tabular-nums truncate">
            <span>شماره ثبت: {artifact.accessionNumber}</span>
            <span aria-hidden="true">·</span>
            <span>{artifact.era}</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => onToggleSave(artifact.id)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                isSaved
                  ? 'bg-[#1E3A8A] text-white border-[#1E3A8A]'
                  : 'bg-[#F9F8F6] text-[#181715] border-[#D6D0C4] hover:border-[#181715]'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" strokeWidth={1.75} />
              <span>{isSaved ? 'در فهرست مطالعه' : 'ذخیره سند'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="بستن پنجره"
              className="p-2 rounded-lg text-[#57534E] hover:text-[#181715] hover:bg-[#E7E2D8] transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto p-6 md:p-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Museum Viewer */}
            <div className="lg:col-span-6 space-y-3">
              <div className="relative aspect-[4/3] rounded-lg overflow-hidden bg-[#EFECE6] border border-[#E2DDD3]">
                <ArchivalImage
                  src={artifact.image}
                  alt={artifact.imageAlt}
                  className={`w-full h-full object-cover transition-transform duration-300 ${
                    zoomed ? 'scale-150 cursor-zoom-out' : 'scale-100 cursor-zoom-in'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setZoomed((prev) => !prev)}
                  className="absolute bottom-3 left-3 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#181715]/85 text-white rounded-md hover:bg-[#181715] transition-colors cursor-pointer"
                >
                  {zoomed ? (
                    <>
                      <ZoomOut className="w-3.5 h-3.5" />
                      <span>نمای کامل</span>
                    </>
                  ) : (
                    <>
                      <ZoomIn className="w-3.5 h-3.5" />
                      <span>بزرگ‌نمایی جزئیات</span>
                    </>
                  )}
                </button>
              </div>
              <p className="font-serif italic text-xs text-[#57534E]">
                {artifact.caption}
              </p>
            </div>

            {/* Accession Metadata DL */}
            <div className="lg:col-span-6 space-y-6">
              <div>
                <h2
                  id="artifact-modal-title"
                  className="font-serif text-2xl md:text-3xl font-bold text-[#181715] leading-snug"
                >
                  {artifact.title}
                </h2>
                <p className="text-sm text-[#44403C] mt-3 leading-loose">
                  {artifact.curatorialNote}
                </p>
              </div>

              <dl className="divide-y divide-[#E2DDD3] border-y border-[#E2DDD3] text-sm">
                <div className="py-3 grid grid-cols-3 gap-4">
                  <dt className="text-[#57534E]">قدمت و دوره</dt>
                  <dd className="col-span-2 text-[#181715] font-medium tabular-nums">
                    {artifact.dateRange}
                  </dd>
                </div>
                <div className="py-3 grid grid-cols-3 gap-4">
                  <dt className="text-[#57534E]">خاستگاه</dt>
                  <dd className="col-span-2 text-[#181715]">{artifact.origin}</dd>
                </div>
                <div className="py-3 grid grid-cols-3 gap-4">
                  <dt className="text-[#57534E]">جنس و فن‌آوری</dt>
                  <dd className="col-span-2 text-[#181715]">{artifact.medium}</dd>
                </div>
                <div className="py-3 grid grid-cols-3 gap-4">
                  <dt className="text-[#57534E]">ابعاد دقیق</dt>
                  <dd className="col-span-2 text-[#181715] tabular-nums">
                    {artifact.dimensions}
                  </dd>
                </div>
                <div className="py-3 grid grid-cols-3 gap-4">
                  <dt className="text-[#57534E]">جایگاه آرشیو</dt>
                  <dd className="col-span-2 text-[#181715]">{artifact.repository}</dd>
                </div>
                <div className="py-3 grid grid-cols-3 gap-4">
                  <dt className="text-[#57534E]">پرونده مرتبط</dt>
                  <dd className="col-span-2 text-[#1E3A8A] font-medium">
                    {artifact.relatedEpisodeTitle}
                  </dd>
                </div>
              </dl>

              <div className="space-y-2">
                <h3 className="text-xs font-semibold text-[#57534E]">
                  پیشینه کشف و ثبت (Provenance)
                </h3>
                <ul className="space-y-2 text-sm text-[#44403C]">
                  {artifact.provenance.map((item) => (
                    <li key={item} className="leading-relaxed">
                      · {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
