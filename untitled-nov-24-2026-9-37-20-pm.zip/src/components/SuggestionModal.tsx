import {FormEvent, useEffect, useState} from 'react';
import {CheckCircle2, X} from 'lucide-react';

interface SuggestionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SuggestionModal({isOpen, onClose}: SuggestionModalProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [topic, setTopic] = useState('');
  const [platform, setPlatform] = useState<'youtube' | 'instagram'>('youtube');
  const [submittedData, setSubmittedData] = useState<{
    topic: string;
    platform: 'youtube' | 'instagram';
  } | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) {
      setError('لطفاً موضوع یا پرسش تاریخی مورد نظرتان را بنویسید.');
      return;
    }
    setError('');
    setSubmittedData({topic: topic.trim(), platform});
    setTopic('');
    setName('');
    setEmail('');
  };

  const handleReset = () => {
    setSubmittedData(null);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="suggestion-modal-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-[#F9F8F6] border border-[#E2DDD3] rounded-xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2DDD3] bg-[#F4F1EA]">
          <h2
            id="suggestion-modal-title"
            className="font-serif text-xl font-bold text-[#181715]"
          >
            پیشنهاد سوژه و عضویت در خبرنامه
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="بستن پنجره"
            className="p-2 rounded-lg text-[#57534E] hover:text-[#181715] hover:bg-[#E7E2D8] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6">
          {submittedData ? (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-2.5 text-[#14532D]">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span className="font-semibold text-base">
                  پیشنهاد شما ثبت شد
                </span>
              </div>
              <p className="text-sm text-[#44403C] leading-relaxed">
                موضوع «{submittedData.topic}» برای بررسی در تقویم تولید{' '}
                {submittedData.platform === 'youtube'
                  ? 'مستندهای یوتیوب'
                  : 'پرونده‌های مصور اینستاگرام'}{' '}
                ثبت گردید.
              </p>
              <button
                type="button"
                onClick={handleReset}
                className="w-full py-2.5 px-4 text-sm font-medium bg-[#1E3A8A] text-white rounded-lg hover:bg-[#172E6E] transition-colors cursor-pointer"
              >
                بازگشت به صفحه اصلی
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <p className="text-sm text-[#44403C] leading-relaxed">
                کدام دوره، سند تاریخی یا بنای فراموش‌شده را برای مستند بعدی یوتیوب یا رشته‌پست اینستاگرام پیشنهاد می‌دهید؟
              </p>

              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-[#57534E]">
                  قالب پیشنهادی
                </label>
                <div className="grid grid-cols-2 gap-2 p-1 bg-[#EFECE6] rounded-lg">
                  <button
                    type="button"
                    onClick={() => setPlatform('youtube')}
                    className={`py-2 px-3 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                      platform === 'youtube'
                        ? 'bg-[#F9F8F6] text-[#181715] shadow-sm'
                        : 'text-[#57534E] hover:text-[#181715]'
                    }`}
                  >
                    مستند یوتیوب
                  </button>
                  <button
                    type="button"
                    onClick={() => setPlatform('instagram')}
                    className={`py-2 px-3 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                      platform === 'instagram'
                        ? 'bg-[#F9F8F6] text-[#181715] shadow-sm'
                        : 'text-[#57534E] hover:text-[#181715]'
                    }`}
                  >
                    پرونده اینستاگرام
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label
                  htmlFor="topic-input"
                  className="block text-xs font-medium text-[#57534E]"
                >
                  موضوع یا پرسش تاریخی
                </label>
                <textarea
                  id="topic-input"
                  rows={3}
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="مثلاً: تاریخچه چاپخانه در ایران قاجار یا مهندسی پل خواجو..."
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#D6D0C4] rounded-lg text-[#181715] placeholder:text-[#A8A29E] focus:outline-none focus:border-[#1E3A8A]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label
                    htmlFor="suggester-name"
                    className="block text-xs font-medium text-[#57534E]"
                  >
                    نام شما (اختیاری)
                  </label>
                  <input
                    id="suggester-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="نام یا شناسه پیج"
                    className="w-full px-3.5 py-2 text-sm bg-white border border-[#D6D0C4] rounded-lg text-[#181715] placeholder:text-[#A8A29E] focus:outline-none focus:border-[#1E3A8A]"
                  />
                </div>
                <div className="space-y-1.5">
                  <label
                    htmlFor="suggester-email"
                    className="block text-xs font-medium text-[#57534E]"
                  >
                    ایمیل برای دریافت خلاصه پژوهش‌ها
                  </label>
                  <input
                    id="suggester-email"
                    type="email"
                    dir="ltr"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full px-3.5 py-2 text-sm bg-white border border-[#D6D0C4] rounded-lg text-[#181715] placeholder:text-[#A8A29E] focus:outline-none focus:border-[#1E3A8A] text-left"
                  />
                </div>
              </div>

              {error && (
                <p className="text-xs text-[#991B1B]" role="alert">
                  {error}
                </p>
              )}

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-medium text-[#57534E] hover:text-[#181715] transition-colors cursor-pointer"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 text-xs font-medium bg-[#1E3A8A] text-white rounded-lg hover:bg-[#172E6E] transition-colors cursor-pointer"
                >
                  ثبت پیشنهاد
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
