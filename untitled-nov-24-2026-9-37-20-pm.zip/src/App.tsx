import {useEffect, useMemo, useState} from 'react';
import {
  ArrowUpLeft,
  Bookmark,
  BookOpen,
  Search,
  Video,
  X,
} from 'lucide-react';
import {
  DOCUMENTARY_RELEASES,
  DocumentaryRelease,
  HERO_FEATURE,
  HISTORICAL_ERAS,
  HISTORICAL_ESSAYS,
  HistoricalEra,
  MUSEUM_ARTIFACTS,
  MuseumArtifact,
  TIMELINE_MILESTONES,
} from './data/historyData';
import {ArchivalImage} from './components/ArchivalImage';
import {EpisodeModal} from './components/EpisodeModal';
import {ArtifactModal} from './components/ArtifactModal';
import {SuggestionModal} from './components/SuggestionModal';

type FormatFilter = 'all' | 'youtube' | 'instagram';

const SAVED_STORAGE_KEY = 'revayat_tarikh_saved_ids_v1';

export default function App() {
  const [formatFilter, setFormatFilter] = useState<FormatFilter>('all');
  const [eraFilter, setEraFilter] = useState<HistoricalEra>('همه ادوار');
  const [searchQuery, setSearchQuery] = useState('');

  const [selectedMilestoneId, setSelectedMilestoneId] = useState<string>(
    TIMELINE_MILESTONES[0].id
  );
  const [selectedEssayId, setSelectedEssayId] = useState<string>(
    HISTORICAL_ESSAYS[0].id
  );

  const [activeEpisode, setActiveEpisode] =
    useState<DocumentaryRelease | null>(null);
  const [activeArtifact, setActiveArtifact] = useState<MuseumArtifact | null>(
    null
  );
  const [isSuggestionOpen, setIsSuggestionOpen] = useState(false);
  const [isReadingListOpen, setIsReadingListOpen] = useState(false);

  const [savedIds, setSavedIds] = useState<string[]>(() => {
    try {
      const raw = window.localStorage.getItem(SAVED_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // Ignore storage access errors
    }
    return ['ep-persepolis', 'art-cyrus'];
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(SAVED_STORAGE_KEY, JSON.stringify(savedIds));
    } catch {
      // Ignore storage write errors
    }
  }, [savedIds]);

  const toggleSaveItem = (id: string) => {
    setSavedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const filteredReleases = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return DOCUMENTARY_RELEASES.filter((item) => {
      if (formatFilter !== 'all' && item.format !== formatFilter) return false;
      if (eraFilter !== 'همه ادوار' && item.era !== eraFilter) return false;
      if (!q) return true;
      return (
        item.title.toLowerCase().includes(q) ||
        item.subtitle.toLowerCase().includes(q) ||
        item.summary.toLowerCase().includes(q) ||
        item.era.toLowerCase().includes(q)
      );
    });
  }, [formatFilter, eraFilter, searchQuery]);

  const activeMilestone = useMemo(
    () =>
      TIMELINE_MILESTONES.find((m) => m.id === selectedMilestoneId) ??
      TIMELINE_MILESTONES[0],
    [selectedMilestoneId]
  );

  const activeEssay = useMemo(
    () =>
      HISTORICAL_ESSAYS.find((e) => e.id === selectedEssayId) ??
      HISTORICAL_ESSAYS[0],
    [selectedEssayId]
  );

  const savedReleases = useMemo(
    () => DOCUMENTARY_RELEASES.filter((r) => savedIds.includes(r.id)),
    [savedIds]
  );

  const savedArtifacts = useMemo(
    () => MUSEUM_ARTIFACTS.filter((a) => savedIds.includes(a.id)),
    [savedIds]
  );

  const openEpisodeById = (id: string) => {
    const found = DOCUMENTARY_RELEASES.find((ep) => ep.id === id);
    if (found) setActiveEpisode(found);
  };

  const openArtifactById = (id: string) => {
    const found = MUSEUM_ARTIFACTS.find((art) => art.id === id);
    if (found) setActiveArtifact(found);
  };

  const jumpToFormat = (fmt: FormatFilter) => {
    setFormatFilter(fmt);
    setEraFilter('همه ادوار');
    setSearchQuery('');
    const el = document.getElementById('releases');
    if (el) el.scrollIntoView({behavior: 'smooth'});
  };

  const resetReleaseFilters = () => {
    setFormatFilter('all');
    setEraFilter('همه ادوار');
    setSearchQuery('');
  };

  return (
    <div id="top" className="min-h-screen bg-[#F9F8F6] text-[#181715]">
      {/* Top Bar Contract: Exactly 3 zones separated by gap-8 */}
      <header className="border-b border-[#E2DDD3] bg-[#F9F8F6]">
        <div className="max-w-[1200px] mx-auto px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single-element Brand Wordmark */}
          <a
            href="#top"
            className="font-serif text-xl font-bold tracking-tight text-[#181715] whitespace-nowrap shrink-0"
          >
            روایت تاریخ
          </a>

          {/* Zone 2: 4 concise single-line nav links */}
          <nav
            aria-label="ناوبری اصلی"
            className="hidden md:flex items-center gap-7 text-sm font-medium text-[#57534E]"
          >
            <a
              href="#releases"
              className="hover:text-[#181715] hover:underline underline-offset-8 decoration-[#1E3A8A] transition-colors whitespace-nowrap shrink-0"
            >
              مستندها
            </a>
            <a
              href="#timeline"
              className="hover:text-[#181715] hover:underline underline-offset-8 decoration-[#1E3A8A] transition-colors whitespace-nowrap shrink-0"
            >
              خط زمان
            </a>
            <a
              href="#artifacts"
              className="hover:text-[#181715] hover:underline underline-offset-8 decoration-[#1E3A8A] transition-colors whitespace-nowrap shrink-0"
            >
              گنجینه اسناد
            </a>
            <a
              href="#essays"
              className="hover:text-[#181715] hover:underline underline-offset-8 decoration-[#1E3A8A] transition-colors whitespace-nowrap shrink-0"
            >
              جستارها
            </a>
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="shrink-0">
            <button
              type="button"
              onClick={() => setIsSuggestionOpen(true)}
              className="px-4 py-2 text-xs font-medium bg-[#1E3A8A] text-white rounded-lg hover:bg-[#172E6E] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              پیشنهاد سوژه
            </button>
          </div>
        </div>
      </header>

      <main>
        {/* Hero Section: Exhibition Marquee Split */}
        <section className="max-w-[1200px] mx-auto px-6 pt-10 pb-12 lg:pt-14 lg:pb-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
            {/* Editorial Copy Column */}
            <div className="lg:col-span-6 flex flex-col justify-between gap-8">
              <div className="space-y-5">
                <p className="text-xs font-medium text-[#57534E]">
                  {HERO_FEATURE.kicker}
                </p>
                <h1 className="font-serif text-3xl sm:text-4xl lg:text-[2.75rem] font-bold text-[#181715] leading-[1.3] [text-wrap:balance]">
                  {HERO_FEATURE.title}
                </h1>
                <p className="text-base text-[#44403C] leading-loose max-w-xl">
                  {HERO_FEATURE.lead}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-5 pt-2">
                <button
                  type="button"
                  onClick={() => openEpisodeById(HERO_FEATURE.episodeId)}
                  className="inline-flex items-center gap-2 px-5 py-3 text-sm font-medium bg-[#1E3A8A] text-white rounded-lg hover:bg-[#172E6E] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Video className="w-4 h-4" strokeWidth={1.75} />
                  <span>مشاهده بخش‌ها و منابع مستند</span>
                </button>
                <a
                  href="#timeline"
                  className="inline-flex items-center gap-1.5 text-sm font-medium text-[#181715] hover:text-[#1E3A8A] underline underline-offset-8 decoration-[#D6D0C4] hover:decoration-[#1E3A8A] transition-colors whitespace-nowrap shrink-0"
                >
                  <span>مرور خط زمان تمدن‌ها</span>
                  <ArrowUpLeft className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Hero Media Frame */}
            <div className="lg:col-span-6 flex flex-col">
              <div className="relative flex-1 min-h-[280px] sm:min-h-[360px] rounded-lg overflow-hidden bg-[#EFECE6] border border-[#E2DDD3]">
                <ArchivalImage
                  src={HERO_FEATURE.image}
                  alt={HERO_FEATURE.imageAlt}
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="font-serif italic text-xs text-[#57534E] mt-3">
                {HERO_FEATURE.caption}
              </p>
            </div>
          </div>

          {/* Operational & Channel Utility Ribbon */}
          <div className="mt-12 border-y border-[#E2DDD3] grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x sm:divide-x-reverse divide-[#E2DDD3]">
            <button
              type="button"
              onClick={() => jumpToFormat('youtube')}
              className="py-5 px-4 text-right hover:bg-[#EFECE6]/60 transition-colors cursor-pointer"
            >
              <span className="block text-xs text-[#57534E]">کانال یوتیوب</span>
              <span className="mt-1 block text-sm font-semibold text-[#181715]">
                آرشیو مستندهای کامل و مآخذ
              </span>
            </button>

            <button
              type="button"
              onClick={() => jumpToFormat('instagram')}
              className="py-5 px-4 text-right hover:bg-[#EFECE6]/60 transition-colors cursor-pointer"
            >
              <span className="block text-xs text-[#57534E]">صفحه اینستاگرام</span>
              <span className="mt-1 block text-sm font-semibold text-[#181715]">
                پرونده‌های مصور و روایت‌های کوتاه
              </span>
            </button>

            <a
              href="#artifacts"
              className="py-5 px-4 text-right hover:bg-[#EFECE6]/60 transition-colors block"
            >
              <span className="block text-xs text-[#57534E]">بازه تاریخی</span>
              <span className="mt-1 block text-sm font-semibold text-[#181715] tabular-nums">
                ۵۵۰ پ.م تا ۱۲۵۹ میلادی
              </span>
            </a>

            <button
              type="button"
              onClick={() => setIsReadingListOpen(true)}
              className="py-5 px-4 text-right hover:bg-[#EFECE6]/60 transition-colors cursor-pointer flex items-center justify-between gap-3"
            >
              <div>
                <span className="block text-xs text-[#57534E]">فهرست مطالعه شما</span>
                <span className="mt-1 block text-sm font-semibold text-[#1E3A8A] tabular-nums">
                  {savedIds.length > 0
                    ? `${savedIds.length} مورد ذخیره‌شده`
                    : 'هنوز موردی ذخیره نشده'}
                </span>
              </div>
              <Bookmark className="w-4 h-4 text-[#1E3A8A] shrink-0" strokeWidth={1.75} />
            </button>
          </div>
        </section>

        {/* Section 1: YouTube Documentaries & Instagram Series Archive */}
        <section
          id="releases"
          className="max-w-[1200px] mx-auto px-6 py-14 border-t border-[#E2DDD3]"
        >
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
            <div className="space-y-2 max-w-2xl">
              <p className="text-xs font-medium text-[#57534E]">
                بخش نخست · آرشیو چندرسانه‌ای کانال
              </p>
              <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#181715]">
                مستندهای یوتیوب و پرونده‌های مصور اینستاگرام
              </h2>
            </div>

            {/* Search Input */}
            <div className="relative w-full lg:w-72 shrink-0">
              <Search
                className="w-4 h-4 text-[#78716C] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                strokeWidth={1.75}
              />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="جستجو در عنوان، دوره یا موضوع..."
                aria-label="جستجو در مستندها و پرونده‌ها"
                className="w-full pr-10 pl-3.5 py-2.5 text-sm bg-white border border-[#D6D0C4] rounded-lg text-[#181715] placeholder:text-[#A8A29E] focus:outline-none focus:border-[#1E3A8A]"
              />
            </div>
          </div>

          {/* Interactive Filter Controls */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-10">
            {/* Format Tabs */}
            <div
              role="group"
              aria-label="فیلتر بر اساس پلتفرم"
              className="flex items-center gap-1 p-1 bg-[#EFECE6] rounded-lg"
            >
              {(
                [
                  {id: 'all', label: 'همه انتشارها'},
                  {id: 'youtube', label: 'مستند یوتیوب'},
                  {id: 'instagram', label: 'پرونده اینستاگرام'},
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFormatFilter(tab.id)}
                  className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    formatFilter === tab.id
                      ? 'bg-[#F9F8F6] text-[#181715] shadow-sm'
                      : 'text-[#57534E] hover:text-[#181715]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Era Filter Buttons */}
            <div
              role="group"
              aria-label="فیلتر بر اساس دوره تاریخی"
              className="flex flex-wrap items-center gap-2"
            >
              {HISTORICAL_ERAS.map((era) => (
                <button
                  key={era}
                  type="button"
                  onClick={() => setEraFilter(era)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    eraFilter === era
                      ? 'border-[#1E3A8A] bg-[#1E3A8A] text-white'
                      : 'border-[#E2DDD3] bg-[#F9F8F6] text-[#57534E] hover:border-[#181715] hover:text-[#181715]'
                  }`}
                >
                  {era}
                </button>
              ))}
            </div>
          </div>

          {/* Results */}
          {filteredReleases.length === 0 ? (
            <div className="py-16 text-center border border-[#E2DDD3] rounded-lg bg-[#F4F1EA]/50 space-y-4">
              <p className="text-sm text-[#44403C]">
                موردی با فیلتر یا عبارت جستجوی شما یافت نشد.
              </p>
              <button
                type="button"
                onClick={resetReleaseFilters}
                className="px-4 py-2 text-xs font-medium bg-[#1E3A8A] text-white rounded-lg hover:bg-[#172E6E] transition-colors cursor-pointer"
              >
                نمایش همه انتشارها
              </button>
            </div>
          ) : (
            <div className="space-y-10">
              {/* Lead Release (Tier 1) */}
              {filteredReleases[0] && (
                <article
                  onClick={() => setActiveEpisode(filteredReleases[0])}
                  className="group grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch border border-[#E2DDD3] bg-[#F4F1EA]/65 rounded-xl overflow-hidden cursor-pointer hover:border-[#B8B0A0] transition-colors"
                >
                  <div className="lg:col-span-6 aspect-[4/3] lg:aspect-auto bg-[#EFECE6] overflow-hidden">
                    <ArchivalImage
                      src={filteredReleases[0].image}
                      alt={filteredReleases[0].imageAlt}
                      className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                    />
                  </div>
                  <div className="lg:col-span-6 p-6 sm:p-8 flex flex-col justify-between gap-6">
                    <div className="space-y-3">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-[#57534E]">
                        <span>{filteredReleases[0].episodeNumber}</span>
                        <span aria-hidden="true">·</span>
                        <span>
                          {filteredReleases[0].format === 'youtube'
                            ? 'مستند یوتیوب'
                            : 'پرونده اینستاگرام'}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums">
                          {filteredReleases[0].durationOrSlides}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{filteredReleases[0].publishedDate}</span>
                      </div>

                      <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#181715] group-hover:text-[#1E3A8A] transition-colors leading-snug">
                        {filteredReleases[0].title}
                      </h3>

                      <p className="text-sm text-[#44403C] leading-relaxed">
                        {filteredReleases[0].subtitle}
                      </p>

                      <p className="text-sm text-[#57534E] leading-loose pt-1">
                        {filteredReleases[0].summary}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-[#E2DDD3]">
                      <span className="text-xs font-medium text-[#1E3A8A]">
                        گشودن فهرست بخش‌ها و منابع ({filteredReleases[0].sources.length} منبع)
                      </span>
                      <ArrowUpLeft className="w-4 h-4 text-[#1E3A8A]" />
                    </div>
                  </div>
                </article>
              )}

              {/* Secondary Features Grid (Tier 2) */}
              {filteredReleases.length > 1 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {filteredReleases.slice(1).map((release) => (
                    <article
                      key={release.id}
                      onClick={() => setActiveEpisode(release)}
                      className="group flex flex-col justify-between border border-[#E2DDD3] bg-[#F9F8F6] rounded-xl overflow-hidden cursor-pointer hover:border-[#B8B0A0] transition-colors"
                    >
                      <div>
                        <div className="aspect-[4/3] bg-[#EFECE6] overflow-hidden border-b border-[#E2DDD3]">
                          <ArchivalImage
                            src={release.image}
                            alt={release.imageAlt}
                            className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                          />
                        </div>
                        <div className="p-6 space-y-3">
                          <div className="flex flex-wrap items-center gap-2 text-xs text-[#57534E]">
                            <span>{release.episodeNumber}</span>
                            <span aria-hidden="true">·</span>
                            <span>
                              {release.format === 'youtube'
                                ? 'مستند یوتیوب'
                                : 'پرونده اینستاگرام'}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span className="tabular-nums">
                              {release.durationOrSlides}
                            </span>
                          </div>

                          <h3 className="font-serif text-xl font-bold text-[#181715] group-hover:text-[#1E3A8A] transition-colors leading-snug">
                            {release.title}
                          </h3>

                          <p className="text-sm text-[#44403C] leading-relaxed line-clamp-3">
                            {release.summary}
                          </p>
                        </div>
                      </div>

                      <div className="px-6 py-4 border-t border-[#E2DDD3] flex items-center justify-between text-xs">
                        <span className="text-[#57534E]">{release.era}</span>
                        <span className="font-medium text-[#1E3A8A] inline-flex items-center gap-1">
                          <span>مشاهده جزئیات</span>
                          <ArrowUpLeft className="w-3.5 h-3.5" />
                        </span>
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </div>
          )}
        </section>

        {/* Section 2: Interactive Historical Timeline */}
        <section
          id="timeline"
          className="bg-[#EFECE6]/70 border-y border-[#E2DDD3] py-16"
        >
          <div className="max-w-[1200px] mx-auto px-6 space-y-10">
            <div className="space-y-2 max-w-2xl">
              <p className="text-xs font-medium text-[#57534E]">
                بخش دوم · گاه‌شمار تحلیلی
              </p>
              <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#181715]">
                خط زمان تمدن‌ها و نقاط عطف تاریخی
              </h2>
              <p className="text-sm text-[#44403C] leading-relaxed">
                روی هر سده یا رخداد کلیک کنید تا روایت تاریخی، جغرافیا و نقل‌قول دست‌اول آن دوره نمایش داده شود.
              </p>
            </div>

            {/* Chronological Rail */}
            <div
              role="tablist"
              aria-label="نقاط عطف خط زمان"
              className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3"
            >
              {TIMELINE_MILESTONES.map((ms, idx) => {
                const isSelected = ms.id === activeMilestone.id;
                return (
                  <button
                    key={ms.id}
                    type="button"
                    role="tab"
                    aria-selected={isSelected}
                    onClick={() => setSelectedMilestoneId(ms.id)}
                    className={`p-4 text-right rounded-lg border transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-[#1E3A8A] text-white border-[#1E3A8A]'
                        : 'bg-[#F9F8F6] text-[#181715] border-[#D6D0C4] hover:border-[#181715]'
                    }`}
                  >
                    <span
                      className={`block text-xs tabular-nums ${
                        isSelected ? 'text-blue-100' : 'text-[#78716C]'
                      }`}
                    >
                      ۰{idx + 1} · {ms.yearLabel}
                    </span>
                    <span className="mt-1.5 block text-sm font-semibold leading-snug line-clamp-2">
                      {ms.title}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Active Milestone Stage */}
            <div className="bg-[#F9F8F6] border border-[#E2DDD3] rounded-xl p-6 sm:p-10">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                <div className="lg:col-span-7 space-y-5">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-[#57534E] tabular-nums">
                    <span>{activeMilestone.yearLabel}</span>
                    <span aria-hidden="true">·</span>
                    <span>{activeMilestone.era}</span>
                    <span aria-hidden="true">·</span>
                    <span>{activeMilestone.location}</span>
                  </div>

                  <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#181715] leading-snug">
                    {activeMilestone.title}
                  </h3>

                  <p className="text-sm sm:text-base text-[#292524] leading-loose">
                    {activeMilestone.narrative}
                  </p>

                  <div className="pt-2 flex flex-wrap items-center gap-4 text-xs text-[#57534E]">
                    <span>
                      چهره‌های شاخص:{' '}
                      <strong className="font-medium text-[#181715]">
                        {activeMilestone.keyFigures}
                      </strong>
                    </span>
                  </div>
                </div>

                {/* Primary Historical Quote with Hairline Top & Bottom Dividers */}
                <div className="lg:col-span-5 flex flex-col justify-between gap-6">
                  <blockquote className="py-6 border-y border-[#D6D0C4] space-y-3">
                    <p className="font-serif italic text-lg sm:text-xl text-[#181715] leading-relaxed">
                      {activeMilestone.primaryQuote}
                    </p>
                    <footer className="text-xs text-[#57534E]">
                      — {activeMilestone.quoteAttribution}
                    </footer>
                  </blockquote>

                  {activeMilestone.relatedArtifactId && (
                    <button
                      type="button"
                      onClick={() =>
                        openArtifactById(activeMilestone.relatedArtifactId!)
                      }
                      className="self-start inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium border border-[#1E3A8A] text-[#1E3A8A] rounded-lg hover:bg-[#1E3A8A] hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <span>مشاهده سند مرتبط در گنجینه موزه</span>
                      <ArrowUpLeft className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Section 3: Museum Artifacts Catalog */}
        <section
          id="artifacts"
          className="max-w-[1200px] mx-auto px-6 py-16"
        >
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div className="space-y-2 max-w-2xl">
              <p className="text-xs font-medium text-[#57534E]">
                بخش سوم · بایگانی باستان‌شناسی
              </p>
              <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#181715]">
                گنجینه آثار و اسناد تاریخی
              </h2>
              <p className="text-sm text-[#44403C] leading-relaxed">
                شناسنامه فنی، ابعاد، پیشینه کشف و یادداشت موزه‌ای آثاری که در مستندهای کانال بررسی شده‌اند.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {MUSEUM_ARTIFACTS.map((artifact) => (
              <article
                key={artifact.id}
                onClick={() => setActiveArtifact(artifact)}
                className="group border border-[#E2DDD3] rounded-xl overflow-hidden bg-[#F4F1EA]/50 cursor-pointer hover:border-[#B8B0A0] transition-colors flex flex-col justify-between"
              >
                <div>
                  <div className="aspect-[4/3] bg-[#EFECE6] overflow-hidden border-b border-[#E2DDD3]">
                    <ArchivalImage
                      src={artifact.image}
                      alt={artifact.imageAlt}
                      className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                    />
                  </div>
                  <div className="p-6 space-y-3">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-[#57534E] tabular-nums">
                      <span>{artifact.accessionNumber}</span>
                      <span aria-hidden="true">·</span>
                      <span>{artifact.dateRange}</span>
                      <span aria-hidden="true">·</span>
                      <span>{artifact.origin}</span>
                    </div>
                    <h3 className="font-serif text-xl font-bold text-[#181715] group-hover:text-[#1E3A8A] transition-colors">
                      {artifact.title}
                    </h3>
                    <p className="text-sm text-[#44403C] leading-relaxed line-clamp-2">
                      {artifact.curatorialNote}
                    </p>
                  </div>
                </div>

                <div className="px-6 py-4 border-t border-[#E2DDD3] flex items-center justify-between text-xs">
                  <span className="text-[#57534E] truncate max-w-[65%]">
                    {artifact.medium}
                  </span>
                  <span className="font-medium text-[#1E3A8A] whitespace-nowrap shrink-0">
                    شناسنامه اثر
                  </span>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* Section 4: Long-form Editorial Essay with Margin Notes (Pattern D) */}
        <section
          id="essays"
          className="border-t border-[#E2DDD3] bg-[#F4F1EA]/60 py-16"
        >
          <div className="max-w-[1200px] mx-auto px-6 space-y-10">
            <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
              <div className="space-y-2 max-w-2xl">
                <p className="text-xs font-medium text-[#57534E]">
                  بخش چهارم · پژوهش‌های مکتوب
                </p>
                <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#181715]">
                  جستارها و پاورقی‌های تاریخی
                </h2>
              </div>

              {/* Essay Selector */}
              <div
                role="tablist"
                aria-label="انتخاب جستار تاریخی"
                className="flex flex-wrap items-center gap-2"
              >
                {HISTORICAL_ESSAYS.map((essay, idx) => {
                  const isActive = essay.id === activeEssay.id;
                  return (
                    <button
                      key={essay.id}
                      type="button"
                      role="tab"
                      aria-selected={isActive}
                      onClick={() => setSelectedEssayId(essay.id)}
                      className={`px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        isActive
                          ? 'bg-[#1E3A8A] text-white border-[#1E3A8A]'
                          : 'bg-[#F9F8F6] text-[#181715] border-[#D6D0C4] hover:border-[#181715]'
                      }`}
                    >
                      {`۰${idx + 1}. ${essay.title.split(':')[0]}`}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Asymmetric 70/30 Editorial Reading Canvas */}
            <div className="bg-[#F9F8F6] border border-[#E2DDD3] rounded-xl p-6 sm:p-10 lg:p-12">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
                {/* Main Reading Column (70%) */}
                <article className="lg:col-span-8 space-y-6">
                  <header className="space-y-3 pb-6 border-b border-[#E2DDD3]">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-[#57534E]">
                      <span>{activeEssay.kicker}</span>
                      <span aria-hidden="true">·</span>
                      <span>{activeEssay.readTime}</span>
                      <span aria-hidden="true">·</span>
                      <span>{activeEssay.publishedDate}</span>
                    </div>
                    <h3 className="font-serif text-2xl sm:text-4xl font-bold text-[#181715] leading-snug [text-wrap:balance]">
                      {activeEssay.title}
                    </h3>
                    <p className="text-xs text-[#57534E]">
                      {activeEssay.author}
                    </p>
                  </header>

                  <figure className="space-y-2.5">
                    <div className="aspect-[16/9] rounded-lg overflow-hidden bg-[#EFECE6] border border-[#E2DDD3]">
                      <ArchivalImage
                        src={activeEssay.coverImage}
                        alt={activeEssay.coverAlt}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <figcaption className="font-serif italic text-xs text-[#57534E]">
                      {activeEssay.coverCaption}
                    </figcaption>
                  </figure>

                  <div className="max-w-prose space-y-5 text-[15px] sm:text-base text-[#292524] leading-[1.95]">
                    <p className="first-letter:text-5xl first-letter:font-serif first-letter:font-bold first-letter:float-right first-letter:ml-3 first-letter:leading-none first-letter:text-[#1E3A8A]">
                      {activeEssay.openingParagraph}
                    </p>
                    {activeEssay.bodyParagraphs.map((para) => (
                      <p key={para.slice(0, 24)}>{para}</p>
                    ))}

                    <blockquote className="my-8 py-6 border-y border-[#D6D0C4] font-serif italic text-xl sm:text-2xl text-[#181715] leading-relaxed text-center">
                      {activeEssay.pullQuote}
                    </blockquote>

                    <p>{activeEssay.closingParagraph}</p>
                  </div>
                </article>

                {/* Margin Notes & Archival Citations Sidebar (30%) */}
                <aside
                  aria-label="حاشیه‌نویسی و منابع جستار"
                  className="lg:col-span-4 space-y-6 lg:border-r lg:border-[#E2DDD3] lg:pr-8"
                >
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#57534E] pb-3 border-b border-[#E2DDD3]">
                    <BookOpen className="w-4 h-4 text-[#1E3A8A]" strokeWidth={1.75} />
                    <span>یادداشت‌ها و مآخذ حاشیه</span>
                  </div>

                  <div className="space-y-6">
                    {activeEssay.marginNotes.map((note) => (
                      <div
                        key={note.number}
                        className="space-y-1.5 pb-5 border-b border-[#E2DDD3] last:border-b-0"
                      >
                        <div className="flex items-center gap-2 text-xs font-semibold text-[#1E3A8A]">
                          <span>[{note.number}]</span>
                          <span>{note.anchorLabel}</span>
                        </div>
                        <p className="text-xs text-[#292524] leading-relaxed">
                          {note.detail}
                        </p>
                        <p className="text-[11px] text-[#78716C] leading-relaxed">
                          منبع: {note.citation}
                        </p>
                      </div>
                    ))}
                  </div>
                </aside>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Clean Editorial Footer */}
      <footer className="border-t border-[#E2DDD3] bg-[#F9F8F6] py-12">
        <div className="max-w-[1200px] mx-auto px-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
          <div className="space-y-2 max-w-md">
            <span className="font-serif text-lg font-bold text-[#181715] block">
              روایت تاریخ
            </span>
            <p className="text-xs text-[#57534E] leading-relaxed">
              پایگاه رسمی آرشیو مستندهای یوتیوب، پرونده‌های مصور اینستاگرام، گاه‌شمار تمدن‌ها و جستارهای مستند تاریخ ایران و جهان.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs font-medium text-[#57534E]">
            <button
              type="button"
              onClick={() => jumpToFormat('youtube')}
              className="hover:text-[#181715] transition-colors cursor-pointer whitespace-nowrap"
            >
              مستندهای یوتیوب
            </button>
            <button
              type="button"
              onClick={() => jumpToFormat('instagram')}
              className="hover:text-[#181715] transition-colors cursor-pointer whitespace-nowrap"
            >
              پرونده‌های اینستاگرام
            </button>
            <button
              type="button"
              onClick={() => setIsReadingListOpen(true)}
              className="hover:text-[#181715] transition-colors cursor-pointer whitespace-nowrap tabular-nums"
            >
              فهرست مطالعه ({savedIds.length})
            </button>
            <button
              type="button"
              onClick={() => setIsSuggestionOpen(true)}
              className="text-[#1E3A8A] hover:underline underline-offset-4 cursor-pointer whitespace-nowrap"
            >
              پیشنهاد سوژه و خبرنامه
            </button>
          </div>
        </div>
      </footer>

      {/* Saved Reading List Modal */}
      {isReadingListOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="reading-list-title"
          onClick={() => setIsReadingListOpen(false)}
        >
          <div
            className="w-full max-w-xl bg-[#F9F8F6] border border-[#E2DDD3] rounded-xl overflow-hidden max-h-[85vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2DDD3] bg-[#F4F1EA]">
              <h2
                id="reading-list-title"
                className="font-serif text-xl font-bold text-[#181715]"
              >
                فهرست مطالعه ذخیره‌شده
              </h2>
              <button
                type="button"
                onClick={() => setIsReadingListOpen(false)}
                aria-label="بستن پنجره"
                className="p-2 rounded-lg text-[#57534E] hover:text-[#181715] hover:bg-[#E7E2D8] transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-6">
              {savedReleases.length === 0 && savedArtifacts.length === 0 ? (
                <p className="text-sm text-[#57534E] py-8 text-center">
                  هنوز مستند یا سندی در فهرست مطالعه خود ذخیره نکرده‌اید.
                </p>
              ) : (
                <>
                  {savedReleases.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="text-xs font-semibold text-[#57534E]">
                        مستندها و پرونده‌ها
                      </h3>
                      <div className="divide-y divide-[#E2DDD3] border border-[#E2DDD3] rounded-lg">
                        {savedReleases.map((ep) => (
                          <div
                            key={ep.id}
                            className="p-4 flex items-center justify-between gap-4"
                          >
                            <button
                              type="button"
                              onClick={() => {
                                setIsReadingListOpen(false);
                                setActiveEpisode(ep);
                              }}
                              className="text-right hover:text-[#1E3A8A] transition-colors cursor-pointer"
                            >
                              <span className="block text-xs text-[#57534E]">
                                {ep.episodeNumber} · {ep.era}
                              </span>
                              <span className="block text-sm font-semibold text-[#181715] mt-0.5">
                                {ep.title}
                              </span>
                            </button>
                            <button
                              type="button"
                              onClick={() => toggleSaveItem(ep.id)}
                              className="text-xs text-[#78716C] hover:text-[#991B1B] shrink-0 cursor-pointer"
                            >
                              حذف
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {savedArtifacts.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="text-xs font-semibold text-[#57534E]">
                        اسناد و آثار موزه
                      </h3>
                      <div className="divide-y divide-[#E2DDD3] border border-[#E2DDD3] rounded-lg">
                        {savedArtifacts.map((art) => (
                          <div
                            key={art.id}
                            className="p-4 flex items-center justify-between gap-4"
                          >
                            <button
                              type="button"
                              onClick={() => {
                                setIsReadingListOpen(false);
                                setActiveArtifact(art);
                              }}
                              className="text-right hover:text-[#1E3A8A] transition-colors cursor-pointer"
                            >
                              <span className="block text-xs text-[#57534E] tabular-nums">
                                {art.accessionNumber} · {art.dateRange}
                              </span>
                              <span className="block text-sm font-semibold text-[#181715] mt-0.5">
                                {art.title}
                              </span>
                            </button>
                            <button
                              type="button"
                              onClick={() => toggleSaveItem(art.id)}
                              className="text-xs text-[#78716C] hover:text-[#991B1B] shrink-0 cursor-pointer"
                            >
                              حذف
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      <EpisodeModal
        release={activeEpisode}
        isSaved={activeEpisode ? savedIds.includes(activeEpisode.id) : false}
        onToggleSave={toggleSaveItem}
        onClose={() => setActiveEpisode(null)}
      />

      <ArtifactModal
        artifact={activeArtifact}
        isSaved={activeArtifact ? savedIds.includes(activeArtifact.id) : false}
        onToggleSave={toggleSaveItem}
        onClose={() => setActiveArtifact(null)}
      />

      <SuggestionModal
        isOpen={isSuggestionOpen}
        onClose={() => setIsSuggestionOpen(false)}
      />
    </div>
  );
}
